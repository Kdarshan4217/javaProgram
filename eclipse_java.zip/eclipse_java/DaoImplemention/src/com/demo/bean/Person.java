package com.demo.bean;

import java.time.LocalDate;

public class Person {
    private	int id;
    private String name;
    private String address;
    private LocalDate bdate;

}
