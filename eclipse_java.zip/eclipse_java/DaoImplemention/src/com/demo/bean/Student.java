package com.demo.bean;

public class Student {

}
