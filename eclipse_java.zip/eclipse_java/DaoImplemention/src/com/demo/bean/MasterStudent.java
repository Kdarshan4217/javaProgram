package com.demo.bean;

public class MasterStudent {

}
