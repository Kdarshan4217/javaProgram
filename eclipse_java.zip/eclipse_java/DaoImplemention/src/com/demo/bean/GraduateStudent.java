package com.demo.bean;

public class GraduateStudent {

}
