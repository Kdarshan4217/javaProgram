import java.util.Date;

public class TestPerson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person1 p1 = new Person1(1,"ABC","1234567890",new Date("12/12/1212"));
	 System.out.println(p1);

	}

}
